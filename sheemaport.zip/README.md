# Sheema Syed Portfolio

A responsive React/Vite portfolio for Sheema Syed, designed around data science, practical problem-solving, and a recruiter-friendly reading flow. The visual system uses dark navy surfaces, soft blue and purple accents, glass-like cards, and subtle motion. The site uses React, Vite, Lucide React icons, Framer Motion, and a carefully scoped custom CSS system rather than utility classes so the visual rhythm stays intentional and lightweight.

## Run locally

```bash
npm install
npm run dev
```

The development server listens on port `3000` and binds to `0.0.0.0` for managed Preview compatibility.

## Build and preview

```bash
npm run build
npm run preview
```

## Add the real assets

The current project intentionally does not fabricate a personal photo or resume PDF because neither was included with the brief. To add them:

1. Add a profile image at `public/assets/sheema-profile.jpg` and replace the initials placeholder in `src/App.tsx` with an image element when ready.
2. Add the actual PDF at `public/resume/Sheema-Syed-Resume.pdf`.
3. Change `resumeAvailable` in `src/App.tsx` to `true` so the download control becomes active.
4. Add real project repository/demo URLs to the `links` arrays in `src/data.ts`; buttons only render when URLs exist.

## Environment variables

None are required. The contact form validates in the browser and opens the visitor's email client with a prepared `mailto:` draft. It does not claim that a message was delivered by the website. If a real email provider is added later, keep provider keys in managed project secrets and replace the submit handler with a server endpoint.

## Deploy or connect GitHub

For a static deployment, use the project’s managed Webdev publish flow with:

- Build command: `npm install && npm run build`
- Output directory: `dist`
- SPA route: `/` (the current site is a single page)

To publish through GitHub Pages, build the project in CI and deploy the generated `dist` directory using an official Pages action. If the repository is connected through the Webdev project, keep the canonical branch on `main` and push the intended checkpoint there.

## Final testing checklist

- Verify the navigation links scroll to About, Skills, Projects, Journey, and Contact on desktop and mobile.
- Verify the mobile menu opens, closes, and remains keyboard reachable.
- Verify project cards do not render fake source/demo URLs.
- Add the real PDF and verify the resume control downloads it.
- Verify contact validation catches empty fields and malformed email addresses; verify the browser mail client draft behavior.
- Check focus styles, contrast, reduced-motion preferences if added, and the layout at 320px, 768px, and desktop widths.
- Run `npm run build` before deployment.
