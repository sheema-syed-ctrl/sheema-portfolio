import { FormEvent, useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  BriefcaseBusiness,
  CheckCircle2,
  ChevronUp,
  Code2,
  Database,
  Download,
  ExternalLink,
  FileDown,
  GraduationCap,
  Mail,
  MapPin,
  Menu,
  Rocket,
  Scale,
  Search,
  Send,
  ShieldCheck,
  Sparkles,
  Terminal,
  X,
} from 'lucide-react';
import { credentials, education, internships, navItems, profile, projects, roles, softSkills, technicalSkills } from './data';

const iconMap = {
  code: Code2,
  sparkles: Sparkles,
  database: Database,
  chart: BarChart3,
  search: Search,
  shield: ShieldCheck,
  scale: Scale,
  rocket: Rocket,
};

function SectionEyebrow({ index, children }: { index: string; children: string }) {
  return (
    <div className="section-eyebrow">
      <span>{index}</span>
      <i />
      <strong>{children}</strong>
    </div>
  );
}

function SocialLinks({ compact = false }: { compact?: boolean }) {
  return (
    <div className={compact ? 'social-links compact' : 'social-links'} aria-label="Social links">
      <a href={profile.github} target="_blank" rel="noreferrer" aria-label="Open GitHub profile">
        <span className="social-mark" aria-hidden="true">GH</span>
        {!compact && <span>GitHub</span>}
      </a>
      <a href={profile.linkedin} target="_blank" rel="noreferrer" aria-label="Open LinkedIn profile">
        <span className="social-mark" aria-hidden="true">in</span>
        {!compact && <span>LinkedIn</span>}
      </a>
    </div>
  );
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('about');
  const [roleIndex, setRoleIndex] = useState(0);
  const [resumeAvailable] = useState(false);
  const [formState, setFormState] = useState({ name: '', email: '', subject: '', message: '' });
  const [formNotice, setFormNotice] = useState<{ type: 'idle' | 'error' | 'ready'; text: string }>({ type: 'idle', text: '' });
  const shouldReduceMotion = useReducedMotion();
  const revealMotion = useMemo(() => ({
    hidden: shouldReduceMotion ? { opacity: 1, y: 0 } : { opacity: 0, y: 24 },
    visible: { opacity: 1, y: 0, transition: { duration: shouldReduceMotion ? 0 : 0.55, ease: 'easeOut' as const } },
  }), [shouldReduceMotion]);

  useEffect(() => {
    const timer = window.setInterval(() => setRoleIndex((current) => (current + 1) % roles.length), 2800);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    const sections = navItems.map((item) => document.querySelector(item.href)).filter(Boolean) as Element[];
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (visible?.target.id) setActiveSection(visible.target.id);
      },
      { rootMargin: '-25% 0px -60% 0px', threshold: [0.1, 0.35, 0.7] },
    );
    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, []);

  const scrollTo = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: shouldReduceMotion ? 'auto' : 'smooth' });
    setMenuOpen(false);
  };

  const resumeCta = useMemo(() => {
    if (resumeAvailable) {
      return <a className="button button-ghost" href="/resume/Sheema-Syed-Resume.pdf" download><Download size={16} /> Download resume</a>;
    }
    return <button className="button button-ghost button-disabled" type="button" title="Add Sheema-Syed-Resume.pdf to public/resume to enable this download"><FileDown size={16} /> Resume coming soon</button>;
  }, [resumeAvailable]);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!formState.name.trim() || !formState.email.trim() || !formState.subject.trim() || !formState.message.trim()) {
      setFormNotice({ type: 'error', text: 'Please complete all fields before preparing your message.' });
      return;
    }
    const emailIsValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formState.email);
    if (!emailIsValid) {
      setFormNotice({ type: 'error', text: 'Please enter a valid email address.' });
      return;
    }
    const body = `Hi Sheema,\n\nName: ${formState.name}\nEmail: ${formState.email}\n\n${formState.message}`;
    window.location.href = `mailto:${profile.email}?subject=${encodeURIComponent(formState.subject)}&body=${encodeURIComponent(body)}`;
    setFormNotice({ type: 'ready', text: 'Your email app should open with a draft addressed to Sheema.' });
  };

  return (
    <div className="site-shell">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <header className="site-header">
        <a className="wordmark" href="#top" onClick={() => scrollTo('#top')} aria-label="Sheema Syed home">
          <span className="wordmark-mark">S<span>.</span></span>
          <span className="wordmark-copy"><strong>sheema</strong><small>data science portfolio</small></span>
        </a>
        <nav id="primary-navigation" className={menuOpen ? 'main-nav is-open' : 'main-nav'} aria-label="Main navigation">
          {navItems.map((item, index) => (
            <a key={item.href} className={activeSection === item.href.slice(1) ? 'is-active' : ''} href={item.href} onClick={() => setMenuOpen(false)}>
              <span>0{index + 1}</span>{item.label}
            </a>
          ))}
        </nav>
        <div className="header-actions">
          <SocialLinks compact />
          <button className="menu-toggle" type="button" aria-controls="primary-navigation" aria-expanded={menuOpen} aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} onClick={() => setMenuOpen((open) => !open)}>
            {menuOpen ? <X size={21} /> : <Menu size={21} />}
          </button>
        </div>
      </header>

      <main id="top">
        <section className="hero section-container" aria-labelledby="hero-title">
          <div className="hero-copy">
            <motion.div initial="hidden" animate="visible" variants={revealMotion} className="hero-kicker"><span className="status-dot" /> {profile.availability}</motion.div>
            <motion.p initial="hidden" animate="visible" variants={revealMotion} className="hero-intro">Hello, I’m</motion.p>
            <motion.h1 initial="hidden" animate="visible" variants={revealMotion} id="hero-title">Sheema <em>Syed</em></motion.h1>
            <div className="hero-role" aria-live="polite">
              <span className="mono-label">currently exploring /</span>
              <AnimatePresence mode="wait"><motion.strong key={roles[roleIndex]} initial={shouldReduceMotion ? false : { opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={shouldReduceMotion ? undefined : { opacity: 0, y: -10 }} transition={{ duration: shouldReduceMotion ? 0 : 0.25 }}>{roles[roleIndex]}</motion.strong></AnimatePresence>
            </div>
            <motion.p initial="hidden" animate="visible" variants={revealMotion} className="hero-description">A Data Science Engineering student passionate about Python, machine learning, data analytics, and building meaningful technology solutions.</motion.p>
            <motion.div initial="hidden" animate="visible" variants={revealMotion} className="hero-actions">
              <button className="button button-primary" type="button" onClick={() => scrollTo('#projects')}>View my projects <ArrowUpRight size={17} /></button>
              {resumeCta}
              <button className="button button-text" type="button" onClick={() => scrollTo('#contact')}>Let’s connect <ArrowRight size={16} /></button>
            </motion.div>
            <div className="hero-footnote"><span className="mono-label">based in</span><span>{profile.location}</span></div>
          </div>
          <motion.div className="hero-visual" initial={shouldReduceMotion ? false : { opacity: 0, scale: 0.94 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: shouldReduceMotion ? 0 : 0.8, delay: shouldReduceMotion ? 0 : 0.2 }}>
            <div className="visual-orbit orbit-one" /><div className="visual-orbit orbit-two" />
            <div className="profile-card">
              <div className="profile-card-top"><span className="mono-label">profile / 001</span><span className="signal-bars"><i /><i /><i /></span></div>
              <div className="avatar-placeholder" aria-label="Profile photo placeholder"><span>{profile.shortName}</span><div className="avatar-grid" /></div>
              <div className="profile-card-bottom"><div><span className="mono-label">focus</span><strong>Data + impact</strong></div><div className="profile-arrow"><ArrowDownRight size={22} /></div></div>
            </div>
            <div className="floating-note note-top"><Terminal size={15} /><span>learning in public</span></div>
            <div className="floating-note note-bottom"><span className="note-index">02</span><span>build / learn / share</span></div>
          </motion.div>
        </section>

        <section id="about" className="section-container content-section about-section" aria-labelledby="about-title">
          <SectionEyebrow index="01" >A little about me</SectionEyebrow>
          <div className="about-layout">
            <div className="section-heading"><h2 id="about-title">Curious by nature.<br /><span>Grounded in purpose.</span></h2></div>
            <div className="about-copy"><p>I’m a Data Science Engineering student at KITS Akshar, building a foundation in Python, machine learning, data analytics, and practical software development.</p><p>I enjoy turning questions into structured problems, then using data and technology to find clear, useful paths forward. Along the way, I’m developing web and AI-based projects that connect technical learning with meaningful real-world use cases.</p><div className="about-signature"><span>Sheema Syed</span><small>data science engineering student / 2027</small></div></div>
          </div>
        </section>

        <section id="skills" className="section-container content-section skills-section" aria-labelledby="skills-title">
          <SectionEyebrow index="02">Tools & ways of thinking</SectionEyebrow>
          <div className="skills-layout"><div className="section-heading"><h2 id="skills-title">A toolkit that<br /><span>keeps growing.</span></h2><p>Not a scorecard — a snapshot of the areas I’m actively learning and applying.</p></div><div className="skills-panels"><div className="skill-panel"><div className="panel-label"><span>01</span><strong>Technical skills</strong></div><div className="skill-list">{technicalSkills.map((skill) => { const Icon = iconMap[skill.icon as keyof typeof iconMap]; return <div className="skill-chip" key={skill.label}><Icon size={17} /><span>{skill.label}</span></div>; })}</div></div><div className="skill-panel"><div className="panel-label"><span>02</span><strong>Soft skills</strong></div><div className="soft-skill-list">{softSkills.map((skill) => <span key={skill}>{skill}</span>)}</div></div></div></div>
        </section>

        <section id="projects" className="section-container content-section projects-section" aria-labelledby="projects-title">
          <SectionEyebrow index="03">Selected work</SectionEyebrow>
          <div className="projects-heading"><div className="section-heading"><h2 id="projects-title">Ideas turned<br /><span>into systems.</span></h2></div><p>Two projects where technology meets practical problem-solving — with room to keep building.</p></div>
          <div className="project-list">{projects.map((project, index) => { const Icon = iconMap[project.icon as keyof typeof iconMap]; return <motion.article className="project-card" key={project.title} initial="hidden" whileInView="visible" viewport={{ once: true, amount: 0.25 }} variants={revealMotion}><div className="project-number">{project.number}</div><div className="project-visual"><Icon size={34} strokeWidth={1.2} /><div className="visual-lines"><i /><i /><i /></div><span>project / {String(index + 1).padStart(2, '0')}</span></div><div className="project-body"><div><span className="project-type">{project.tags.join(' · ')}</span><h3>{project.title}</h3><h4>{project.subtitle}</h4><p>{project.description}</p></div><div className="project-footer"><span className="project-status"><span className="status-dot" /> Details available on request</span>{project.links.length > 0 ? <div className="project-links">{project.links.map((link) => <a key={link.href} href={link.href} target="_blank" rel="noreferrer">{link.label} <ExternalLink size={14} /></a>)}</div> : <span className="project-muted">Source & demo links coming soon</span>}</div></div></motion.article>; })}</div>
        </section>

        <section id="journey" className="section-container content-section journey-section" aria-labelledby="journey-title">
          <SectionEyebrow index="04">The journey so far</SectionEyebrow>
          <div className="journey-layout"><div className="section-heading"><h2 id="journey-title">Learning through<br /><span>real experience.</span></h2><p>Every project and internship is another way to turn curiosity into capability.</p></div><div className="timeline-column"><div className="timeline-block"><div className="timeline-label"><BriefcaseBusiness size={17} /><span>Experience</span></div>{internships.map((item) => <article className="timeline-item" key={item.role}><div className="timeline-marker"><span className={item.current ? 'current' : ''} /></div><div className="timeline-content"><div className="timeline-meta"><span>{item.period}</span>{item.current && <span className="current-pill">Current</span>}</div><h3>{item.role}</h3>{item.organization && <h4>{item.organization}</h4>}<p>{item.description}</p><div className="highlight-row">{item.highlights.map((highlight) => <span key={highlight}>{highlight}</span>)}</div></div></article>)}</div><div className="timeline-block education-block"><div className="timeline-label"><GraduationCap size={17} /><span>Education</span></div>{education.map((item) => <article className="education-item" key={item.degree}><div><span className="timeline-period">{item.period}</span><h3>{item.degree}</h3><p>{item.school}</p></div><strong>{item.result}</strong></article>)}</div></div></div>
        </section>

        <section id="credentials" className="section-container content-section credentials-section" aria-labelledby="credentials-title">
          <SectionEyebrow index="05">Credentials & curiosity</SectionEyebrow>
          <div className="credentials-heading"><div className="section-heading"><h2 id="credentials-title">Always making<br /><span>space to learn.</span></h2></div><p>Workshops, programmes, and hackathons that mark the moments I chose to explore something new.</p></div>
          <div className="credential-grid">{credentials.map((item, index) => { const Icon = iconMap[item.icon as keyof typeof iconMap]; return <motion.article className="credential-card" key={item.title} initial="hidden" whileInView="visible" viewport={{ once: true }} variants={revealMotion} transition={{ delay: shouldReduceMotion ? 0 : index * 0.06 }}><div className="credential-top"><Icon size={19} /><span>{item.date}</span></div><div><span className="credential-type">{item.type}</span><h3>{item.title}</h3></div><ArrowUpRight size={17} className="credential-arrow" /></motion.article>; })}</div>
        </section>

        <section id="contact" className="section-container content-section contact-section" aria-labelledby="contact-title">
          <div className="contact-card"><div className="contact-copy"><SectionEyebrow index="06">Start a conversation</SectionEyebrow><h2 id="contact-title">Have a question,<br /><em>idea, or opportunity?</em></h2><p>I’m always glad to hear from people building thoughtful things with data and technology.</p><div className="contact-details"><a href={`mailto:${profile.email}`}><Mail size={17} /><span>{profile.email}</span><ArrowUpRight size={15} /></a><span><MapPin size={17} /><span>{profile.location}</span></span></div><SocialLinks /></div><form className="contact-form" onSubmit={handleSubmit} noValidate><div className="form-row"><label><span>Name</span><input value={formState.name} onChange={(event) => setFormState({ ...formState, name: event.target.value })} placeholder="Your name" /></label><label><span>Email</span><input type="email" value={formState.email} onChange={(event) => setFormState({ ...formState, email: event.target.value })} placeholder="you@example.com" /></label></div><label><span>Subject</span><input value={formState.subject} onChange={(event) => setFormState({ ...formState, subject: event.target.value })} placeholder="What would you like to talk about?" /></label><label><span>Message</span><textarea rows={5} value={formState.message} onChange={(event) => setFormState({ ...formState, message: event.target.value })} placeholder="Tell me a little about it..." /></label>{formNotice.type !== 'idle' && <p className={formNotice.type === 'error' ? 'form-notice error' : 'form-notice ready'} role="status">{formNotice.type === 'error' ? <X size={16} /> : <CheckCircle2 size={16} />}{formNotice.text}</p>}<button className="button button-primary form-submit" type="submit">Prepare email <Send size={16} /></button><p className="form-helper">This form opens your email app; no message is sent from this website.</p></form></div>
        </section>
      </main>

      <footer className="site-footer section-container"><div className="footer-brand"><a className="wordmark" href="#top" onClick={() => scrollTo('#top')}><span className="wordmark-mark">S<span>.</span></span><span className="wordmark-copy"><strong>sheema</strong><small>data science portfolio</small></span></a><p>Building a data-informed path, one question at a time.</p></div><div className="footer-right"><SocialLinks compact /><button type="button" className="back-top" onClick={() => scrollTo('#top')}>Back to top <ChevronUp size={16} /></button><p>© {new Date().getFullYear()} Sheema Syed. Built with intention.</p></div></footer>
    </div>
  );
}

export default App;
