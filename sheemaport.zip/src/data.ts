export type Link = { label: string; href: string };

export const profile = {
  name: 'Sheema Syed',
  shortName: 'SS',
  role: 'Data Science Engineering Student',
  location: 'Guntur, Andhra Pradesh, India',
  email: 'syedsheema070@gmail.com',
  linkedin: 'https://www.linkedin.com/in/sheema-syed-17349b376',
  github: 'https://github.com/sheema-syed-ctrl',
  availability: 'Open to learning, collaborating, and meaningful opportunities',
};

export const navItems = [
  { label: 'About', href: '#about' },
  { label: 'Skills', href: '#skills' },
  { label: 'Projects', href: '#projects' },
  { label: 'Journey', href: '#journey' },
  { label: 'Credentials', href: '#credentials' },
  { label: 'Contact', href: '#contact' },
];

export const roles = ['Aspiring Data Scientist', 'Python Developer', 'Data Analytics Learner'];

export const technicalSkills = [
  { label: 'Python', icon: 'code' },
  { label: 'Machine Learning', icon: 'sparkles' },
  { label: 'SQL', icon: 'database' },
  { label: 'Data Analytics', icon: 'chart' },
  { label: 'Exploratory Data Analysis', icon: 'search' },
];

export const softSkills = [
  'Analytical Thinking',
  'Problem Solving',
  'Communication Skills',
  'Team Collaboration',
  'Leadership',
  'Willingness to Learn',
];

export const projects = [
  {
    number: '01',
    title: 'AP Suraksha',
    subtitle: 'Smart Vehicle Number Plate Detection System',
    description: 'An AI-powered vehicle detection and license plate recognition concept using OCR, focused on practical monitoring and security use cases.',
    tags: ['AI concept', 'OCR', 'Vehicle security'],
    icon: 'shield',
    links: [] as Link[],
  },
  {
    number: '02',
    title: 'Justice Connect',
    subtitle: 'Legal Services Platform',
    description: 'A web platform that connects clients and lawyers through lawyer profiles, appointment booking, user authentication, and secure communication.',
    tags: ['Django', 'Web platform', 'Legal tech'],
    icon: 'scale',
    links: [] as Link[],
  },
];

export const internships = [
  {
    period: 'Ongoing',
    role: 'Finance Intern',
    organization: 'SikshaVersa',
    description: 'Working with financial data analysis and reporting using Python, SQL, and MS Excel, while applying data-driven and machine-learning-based approaches to financial insights.',
    highlights: ['Team collaboration', 'Git version control', 'Documentation'],
    current: true,
  },
  {
    period: 'May 2025 — July 2025',
    role: 'Data Science & Big Data Analysis Intern',
    organization: '',
    description: 'Worked across data collection, cleaning, preprocessing, statistical analysis, and Python-based data visualization and reporting to surface data-driven insights.',
    highlights: ['Data preprocessing', 'Statistical analysis', 'Python visualization'],
    current: false,
  },
];

export const education = [
  { period: '2023 — 2027', degree: 'B.Tech in Data Science', school: 'KITS Akshar', result: 'CGPA 7.87' },
  { period: '2021 — 2023', degree: 'Intermediate', school: 'Vrinda Mahila Junior College', result: '75%' },
  { period: '2020 — 2021', degree: 'SSC', school: 'Bhavishya School', result: '93%' },
];

export const credentials = [
  { date: 'Oct 2025', title: 'Workshop on User Interface Design Using Flutter', type: 'Workshop', icon: 'sparkles' },
  { date: 'Aug 2024', title: 'Python Applications', type: 'Two-Week Certificate Programme', icon: 'code' },
  { date: 'Feb 2026', title: 'Six-Day Ideathon & Hackathon on Python with Django', type: 'Hackathon', icon: 'rocket' },
  { date: 'Jul 2026', title: 'Mission Youth 4 – Prakasam Police Hackathon', type: 'Hackathon', icon: 'shield' },
];
